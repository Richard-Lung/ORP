Steps to initialize and create route:

1. Edit the HTML file and add API key of google API.

2. Run the HTML file and choose points on map.

3. Press "Generate Elevation Grid", wait to finish.

4. Once finished, click "Download Elevation Data" to download the csv.

5. run "AStar.py" algorithm, make sure that you edit the line in main instead of "data.csv" from step 4.

6. See the plotted route!