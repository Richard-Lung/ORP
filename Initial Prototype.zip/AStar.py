import pandas as pd
import math
import heapq
import matplotlib.pyplot as plt

# ============================
# CONSTANTS & DATA STRUCTURE
# ============================
LAT_LON_THRESHOLD = 0.0003  # Maximum allowed difference (lat or lon) for connectivity
ELEVATION_THRESHOLD = 6      # Maximum allowed elevation difference

class Point:
    def __init__(self, id, lat, lon, elevation, point_type):
        self.id = id
        self.lat = lat
        self.lon = lon
        self.elevation = elevation
        self.point_type = point_type
        self.neighbors = []  # Will hold tuples: (neighbor_id, cost)

# ============================
# DATA LOADING & GRAPH BUILDING
# ============================
def load_points_from_csv(file_path):
    df = pd.read_csv(file_path)
    points = {}
    for idx, row in df.iterrows():
        points[idx] = Point(idx, row['lat'], row['lng'], row['elevation'], row['point_type'])
    return points

def are_adjacent(p1, p2):
    # Two points are adjacent if the difference in lat OR lon is within threshold.
    return (abs(p1.lat - p2.lat) <= LAT_LON_THRESHOLD or 
            abs(p1.lon - p2.lon) <= LAT_LON_THRESHOLD)

def elevation_difference(p1, p2):
    return abs(p1.elevation - p2.elevation)

def build_graph(points):
    # Connect every pair of points that are "adjacent" and have acceptable elevation difference.
    for i, p1 in points.items():
        for j, p2 in points.items():
            if i != j and are_adjacent(p1, p2):
                diff = elevation_difference(p1, p2)
                if diff <= ELEVATION_THRESHOLD:
                    p1.neighbors.append((j, diff))
    return points

# ============================
# HEURISTIC & PATH RECONSTRUCTION
# ============================
def haversine_distance(p1, p2):
    # Compute the great-circle distance between two points (in meters).
    R = 6371000  # Earth radius in meters
    phi1 = math.radians(p1.lat)
    phi2 = math.radians(p2.lat)
    d_phi = math.radians(p2.lat - p1.lat)
    d_lambda = math.radians(p2.lon - p1.lon)
    a = math.sin(d_phi/2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def reconstruct_path(came_from, start_id, goal_id):
    # Reconstruct the final path by backtracking from goal to start.
    path = [goal_id]
    current = goal_id
    while current != start_id:
        current = came_from[current]
        path.append(current)
    path.reverse()
    return path

# ============================
# SIMPLE A* ALGORITHM
# ============================
def astar(points, start_id, goal_id):
    open_set = []
    heapq.heappush(open_set, (0, start_id))
    came_from = {}
    g_score = {start_id: 0}
    f_score = {start_id: haversine_distance(points[start_id], points[goal_id])}
    closed_set = set()

    while open_set:
        _, current = heapq.heappop(open_set)
        if current == goal_id:
            return reconstruct_path(came_from, start_id, goal_id)
        closed_set.add(current)
        for neighbor_id, cost in points[current].neighbors:
            if neighbor_id in closed_set:
                continue
            tentative_g = g_score[current] + cost
            if neighbor_id not in g_score or tentative_g < g_score[neighbor_id]:
                came_from[neighbor_id] = current
                g_score[neighbor_id] = tentative_g
                f_score[neighbor_id] = tentative_g + haversine_distance(points[neighbor_id], points[goal_id])
                heapq.heappush(open_set, (f_score[neighbor_id], neighbor_id))
    return None

# ============================
# SMOOTHING FUNCTIONS (PRESERVING KEY POINTS)
# ============================
def is_direct_connection(p1, p2):
    # Returns True if a direct connection from p1 to p2 is allowed.
    return are_adjacent(p1, p2) and elevation_difference(p1, p2) <= ELEVATION_THRESHOLD

def smooth_path(path, points):
    """
    Remove unnecessary intermediate nodes from the path by checking if a direct connection
    exists between a node and a later node. Endpoints are preserved.
    """
    if len(path) < 3:
        return path
    smoothed = [path[0]]
    i = 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1:
            if is_direct_connection(points[path[i]], points[path[j]]):
                smoothed.append(path[j])
                i = j
                break
            j -= 1
        else:
            smoothed.append(path[i+1])
            i += 1
    return smoothed

def smooth_path_preserve_keys(path, points, key_points):
    """
    Smooth the path between each consecutive pair of key points separately,
    ensuring that the key points are preserved.
    """
    final_route = []
    for i in range(len(key_points) - 1):
        # Find the segment of the path between key_points[i] and key_points[i+1]
        try:
            start_index = path.index(key_points[i])
            end_index = path.index(key_points[i+1])
        except ValueError:
            # If a key point is not in path, force it in by using its index in the original order.
            continue
        segment = path[start_index:end_index+1]
        smoothed_segment = smooth_path(segment, points)
        if i == 0:
            final_route.extend(smoothed_segment)
        else:
            final_route.extend(smoothed_segment[1:])  # Skip duplicate key point.
    return final_route

# ============================
# FULL PATH WITH WAYPOINTS (NO EXTRA FEATURES)
# ============================
def astar_full_path(points):
    """
    Run A* for each segment between key points (start, waypoints, end)
    and then apply smoothing per segment to preserve all key points.
    """
    # Identify key points.
    start_id = [p.id for p in points.values() if p.point_type == 'start'][0]
    end_id = [p.id for p in points.values() if p.point_type == 'end'][0]
    waypoints = [p for p in points.values() if p.point_type.startswith("w")]
    # Sort waypoints (if numbered, sort by numeric part).
    waypoints_sorted = sorted(waypoints, key=lambda p: int(p.point_type[1:]) if p.point_type[1:].isdigit() else 0)
    route_ids = [start_id] + [p.id for p in waypoints_sorted] + [end_id]

    full_path = []
    # Run A* for each segment and concatenate.
    for i in range(len(route_ids) - 1):
        seg_start = route_ids[i]
        seg_end = route_ids[i+1]
        seg_path = astar(points, seg_start, seg_end)
        if seg_path is None:
            print(f"❌ Failed to find path from {points[seg_start].point_type} to {points[seg_end].point_type}")
            return None, route_ids
        if full_path:
            full_path.extend(seg_path[1:])  # avoid duplicate key point
        else:
            full_path.extend(seg_path)
    # Now smooth the full path while preserving key points.
    final_path = smooth_path_preserve_keys(full_path, points, route_ids)
    return final_path, route_ids

# ============================
# PLOTTING: COLOR EACH SEGMENT DIFFERENTLY
# ============================
def plot_path_with_segments(points, full_path, route_ids):
    plt.figure(figsize=(10, 8))
    # Always draw the entire path as a thin black line.
    all_lats = [points[pid].lat for pid in full_path]
    all_lons = [points[pid].lon for pid in full_path]
    plt.plot(all_lons, all_lats, color='black', linewidth=1, label="Full Path")
    
    # Define colors for segments.
    segment_colors = ['blue', 'green', 'orange', 'purple', 'brown', 'teal', 'magenta', 'cyan']
    for i in range(len(route_ids) - 1):
        kp_start = route_ids[i]
        kp_end = route_ids[i+1]
        if kp_start in full_path and kp_end in full_path:
            idx_start = full_path.index(kp_start)
            idx_end = full_path.index(kp_end)
            if idx_start > idx_end:
                idx_start, idx_end = idx_end, idx_start
            seg_lats = [points[pid].lat for pid in full_path[idx_start:idx_end+1]]
            seg_lons = [points[pid].lon for pid in full_path[idx_start:idx_end+1]]
            color = segment_colors[i % len(segment_colors)]
            plt.plot(seg_lons, seg_lats, color=color, linewidth=3,
                     label=f"{points[kp_start].point_type}→{points[kp_end].point_type}")
    
    # Mark and annotate key points.
    for pid in route_ids:
        if pid in full_path:
            p = points[pid]
            plt.scatter(p.lon, p.lat, color='red', s=50)
            plt.text(p.lon, p.lat, p.point_type, fontsize=12, ha='right', color='red')
        else:
            print(f"Warning: Key point {pid} not in final path!")
    
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.title("Simple A* Path with Preserved Waypoints and Colored Segments")
    plt.legend()
    plt.grid(True)
    plt.show()

# ============================
# EXPORTING THE PATH
# ============================
def export_path_to_csv(path, points, output_file):
    data = []
    for pid in path:
        p = points[pid]
        data.append({
            'lat': p.lat,
            'lng': p.lon,
            'elevation': p.elevation,
            'point_type': p.point_type
        })
    pd.DataFrame(data).to_csv(output_file, index=False)
    print(f"✅ Path exported to {output_file}")

# ============================
# MAIN
# ============================
if __name__ == "__main__":
    # Replace "input_points.csv" with your CSV file path.
    points = load_points_from_csv("data.csv")
    build_graph(points)
    
    result = astar_full_path(points)
    if result is None:
        print("No valid path found!")
    else:
        final_path, route_ids = result
        print("Final path (node IDs):", final_path)
        print("Key route IDs:", route_ids)
        plot_path_with_segments(points, final_path, route_ids)
        export_path_to_csv(final_path, points, "simple_astar_preserve_keys_path.csv")
