from flask import Flask, request, send_file
from flask_cors import CORS
import pandas as pd
import io
from AStar import run_astar

app = Flask(__name__)
CORS(app)  # ALLOW all cross-origin requests

@app.route('/process_csv', methods=['POST'])
def process_csv():
    file = request.files['file']
    df = pd.read_csv(file)

    # Run your A* algorithm
    result_df = run_astar(df)

    # Return path as CSV
    output = io.StringIO()
    result_df.to_csv(output, index=False)
    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv')

if __name__ == '__main__':
    app.run(debug=True)
